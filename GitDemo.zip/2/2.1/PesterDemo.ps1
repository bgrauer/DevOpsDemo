﻿function PesterDemo {

    Stop-Service bits

    if((Get-Service bits).status -eq "running")
    {
        Throw 'Failed to stop service - Bits'
    }

}

