﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "PesterDemo" {
    
    BeforeAll{
        New-Item -Path TestDrive:\SomeFile.txt -ItemType File
    }

    It "Finds the file Blah.txt" {

        PesterDemo -path TestDrive:\SomeFile.txt | Should -Be $true
    }
}
