﻿function PesterDemo {
    
   param($path)
   
   If(Test-Path $path)
   {
        return $true
   } 
    
}
