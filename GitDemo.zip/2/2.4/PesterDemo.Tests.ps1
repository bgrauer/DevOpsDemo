﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "Get-ProdWebSiteName" {
    Context "New Module"{
        BeforeAll{
            New-Module -Name PesterMocks {

                function Get-WebSite {}
    
            } | Import-Module -Force

            Mock Get-Website {
                $props = @{
                "name" = 'Default Web Site'
                }
                return New-Object psobject -Property $props 
            }# end Mock
        }

        AfterAll{
            Remove-Module PesterMocks -Force    
        }
        

        It "Returns 'Default Web Site'" {
        
            $actual = Get-ProdWebSiteName
            $expected = 'Default Web Site'
    
            $actual | Should -Be $expected
        }
    
    }
 
}
