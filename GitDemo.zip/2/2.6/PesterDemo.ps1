﻿function Get-ProdWebSiteName {
    
    $ALLSites = Get-WebSite
    $ProdSites = @()

    foreach($site in $AllSites)
    {
        if($site.name -notmatch "^DEV_")
        {
            $ProdSites += $site.Name
        }
    }

    return ($ProdSites)
}
