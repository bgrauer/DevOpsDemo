﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"


Describe -tag DEV "Get-ProdWebSiteName" {
    
    
    
    BeforeAll{

        Remove-Module PesterMocks -ErrorAction SilentlyContinue

        New-Module -Name PesterMocks {
            
            function Get-WebSite {}

        } | Import-Module -Force
    }
    
    Context "One Production site exits" {
    
        BeforeEach {
            Mock Get-Website {
                $props = @{
                "name" = 'Default Web Site'
                }
                return New-Object psobject -Property $props 
            }  
        }

        It "Returns 'Default Web Site'" {

            $actual = Get-ProdWebSiteName
            $expected = 'Default Web Site'

            $actual | Should -Be $expected
        }
       
    }# end context
    
    Context "Multiple Production sites exist" {
        
        BeforeEach{
            Mock Get-Website {
                    $return = @()
                    $return += New-Object psobject -Property @{"name" = "CRM"}
                    $return += New-Object psobject -Property @{"name" = "Dev_DefaultWS"}
                    $return += New-Object psobject -Property @{"name" = "Default Web Site"}

                    return $return
            }
        }

        It "Returns 'Default Web Site' -AND 'CRM'" {
        
            (Get-ProdWebSiteName)[0] | Should -Be "CRM"
            (Get-ProdWebSiteName)[1] | Should -Be "Default Web Site"
        }

        It "Returns 2 site objects" {
            
            (Get-ProdWebSiteName).count | Should -Be 2

        }

        

    }# end context
    
} 

Describe -tag PROD "Get-ProdWebSiteName" {
     
    Context "One Production site exits" {
            
        It "Returns 'Default Web Site'" {
        
            $actual = Get-ProdWebSiteName
            $expected = 'Default Web Site'

            $actual | Should -Be $expected
        }
       
    }# end context
    
    Context "Multiple Production sites exist" {
        
       
        It "Returns 'Default Web Site' -AND 'CRM'" {
        
            $actual = Get-ProdWebSiteName
            $expected = 'Default Web Site'

            (Get-ProdWebSiteName)[0] | Should -Be "CRM"
            (Get-ProdWebSiteName)[1] | Should -Be "Default Web Site"
        }

        It "Returns 2 site objects" {
            
            (Get-ProdWebSiteName).count | Should -Be 2

        }

   

    }# end context
    
 
} 


# Invoke-Pester -Script .\PesterDemo.Tests.ps1 -Tag Dev
# Invoke-Pester -Script .\PesterDemo.Tests.ps1 -Tag PROD

# $TestResults = Invoke-Pester -Script .\PesterDemo.Tests.ps1 -Tag Dev -PassThru

# $TestResults.TestResult