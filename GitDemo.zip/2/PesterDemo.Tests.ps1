﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "PesterDemo" {
    It "Stops the bits service" {
        
        Start-Service bits # Arrange
        
        PesterDemo # Act

        (Get-Service bits).Status | Should Be "Stopped" # Assert
    }

    It "Throws an error if service does not stop" {
        
        Start-Service bits

        {PesterDemo} | Should Throw
    }
}
