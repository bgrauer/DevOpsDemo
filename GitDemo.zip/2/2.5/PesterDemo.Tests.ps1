﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "Get-ProdWebSiteName" {
    Context "One Production site exits" {
        BeforeAll{
        Remove-Module PesterMocks -ErrorAction SilentlyContinue
        New-Module -Name PesterMocks {
        
            function Get-WebSite {}

        } | Import-Module -Force

        Mock Get-Website {
                $props = @{
                "name" = 'Default Web Site'
            }
            return New-Object psobject -Property $props 
        } 
    }

        It "Returns 'Default Web Site'" {
            
            $expected = 'Default Web Site'

            $actual = Get-ProdWebSiteName
            
            $actual | Should -Be $expected
        }
       
    }# end context
    
    Context "Multiple Production sites exist" {
       BeforeAll{
           Mock Get-Website {
               $return = @()
               $return += New-Object psobject -Property @{"name" = "CRM"}
               $return += New-Object psobject -Property @{"name" = "Dev_DefaultWS"}
               $return += New-Object psobject -Property @{"name" = "Default Web Site"}

                return $return
            }

            $actual = Get-ProdWebSiteName
       } 
       
        It "Returns 'Default Web Site' -AND 'CRM'" {
            
            $actual[0] | Should -Be "CRM"
            $actual[1] | Should -Be "Default Web Site"
        }

        It "Returns 2 site objects" {
            
            $actual.count | Should -Be 2

        }
      

    }# end context
    
 
}
