﻿function Get-ProdWebSiteName {
    
    $sites = Get-WebSite
    $return = @()

    foreach($site in $Sites)
    {
        if($site.name -notmatch "^DEV_")
        {
            $return += $site.Name
        }
    }

    return $return
}
