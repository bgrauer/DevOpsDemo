﻿function Get-ProdWebSiteName {
    
    $sites = Get-WebSite

    foreach($site in $Sites)
    {
        if($site.name -notmatch "^DEV_")
        {
            return $site.Name
        }
    }
}
