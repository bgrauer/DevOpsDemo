﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "Get-ProdWebSiteName" {
   
    It "Returns 'Default Web Site'" {
        
        # Arrange
        Mock Get-Website {
            $props = @{
            "name" = 'Default Web Site'
            }
            return New-Object psobject -Property $props 
        }# end Mock

        $expected = 'Default Web Site' 

        $actual = (Get-ProdWebSiteName).Name # Act

        $actual | Should -Be $expected # Assert
    }
}
