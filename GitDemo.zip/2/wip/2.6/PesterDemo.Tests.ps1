﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe -tag Dev "Get-ProdWebSiteName" {
    
    New-Module -Name PesterMocks {
        
        function Get-WebSite {}

    } | Import-Module -Force

    It "Returns 'Default Web Site'" {
        Mock Get-Website {
            $props = @{
            "name" = 'Default Web Site'
            }
            return New-Object psobject -Property $props 
        }# end Mock

        $actual = Get-ProdWebSiteName
        $expected = 'Default Web Site'

        $actual | Should Be $expected
    }

    Remove-Module PesterMocks
}

Describe -tag ValidateEnvironment "Get-ProdWebSiteName" {
    
   It "Returns 'Default Web Site'" {
       
        $actual = Get-ProdWebSiteName
        $expected = 'Default Web Site'

        $actual | Should Be $expected
    }

    
}


# Invoke-Pester -Script .\PesterDemo.Tests.ps1 -Tag Dev
# Invoke-Pester -Script .\PesterDemo.Tests.ps1 -Tag ValidateEnvironment

# $TestResults = Invoke-Pester -Script .\PesterDemo.Tests.ps1 -Tag Dev -PassThru

# $TestResults.TestResult