﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "PesterDemo" {
    
    Context "Stops single service defined in File" {
        
        #Arrange
        Add-Content "testdrive:\services.txt" -Value "bits"
        Start-Service bits 
        
        It "Stops single service" {
        
            PesterDemo -path "testdrive:\services.txt" # Act

            (Get-Service bits).Status | Should Be "Stopped" # Assert
        }

    }# end context

    Context "Stops a single service passed as param" {

        #Arrange
        Start-Service bits

        It "Stops single services " {
        
            PesterDemo -service "bits"
            (Get-Service Bits).status | Should Be "Stopped"
        }
    }# end context

    Context "Stops multiple services read from file" {
        
        #Arrange
        Add-Content "testdrive:\services.txt" -Value @("bits", "spooler")
        Start-Service "bits", "spooler" 
        
        It "Stops multiple services" {
        
            PesterDemo -path "testdrive:\services.txt" # Act

            (Get-Service bits).Status | Should Be "Stopped" # Assert
            (Get-Service spooler).Status | Should Be "Stopped" # Assert
        }

    }

  
}
