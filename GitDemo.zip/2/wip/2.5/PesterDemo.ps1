﻿function PesterDemo {

    param ($service, $path = "")

    if($service -eq $null)
    {
        $service = Get-Content $path
    }
    
    foreach($svc in $service)
    {
        Stop-Service $svc

        if((Get-Service $svc).status -eq "running")
        {
            Throw
        }
    }

     

}



