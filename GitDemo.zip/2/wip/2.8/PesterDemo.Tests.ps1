﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "Get-ProdWebSiteName" {
    
    New-Module -Name PesterMocks {
        
            function Get-WebSite {}

        } | Import-Module -Force
    
    Context "Single Prod Site returned" {
    
        Mock Get-Website {
                        
            $return = @()

            $return += New-Object psobject -Property @{"name" = 'Default Web Site'}
            $return += New-Object psobject -Property @{"name" = 'Dev_Site'}

            return $return

        }# end Mock

        It "Returns 'Default Web Site'" {
            
            $actual = Get-ProdWebSiteName
            $expected = 'Default Web Site'

            $actual | Should Be $expected
        }

        It "returns only Default Web site, not Dev Site" {
            $true | Should Be $true
        }


    }# end context

    Context "Multiple Prod Sites returned" {

         Mock Get-Website {
                        
            $return = @()

            $return += New-Object psobject -Property @{"name" = 'Default Web Site'}
            $return += New-Object psobject -Property @{"name" = 'Some Other Production Site'}
            $return += New-Object psobject -Property @{"name" = 'Dev_Site'}


            return $return

        }# end Mock

        It "returns 2 sites" {

            (Get-ProdWebSiteName).count | Should Be 2
        }

        It "returns site 'Some Other Production site'" {
            
            (Get-ProdWebSiteName) -contains 'Some Other Production Site' | Should Be $True
        }

    
    }# end context

    Remove-Module PesterMocks
}
