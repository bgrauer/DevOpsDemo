﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

cls
Describe "Add-Numbers" {
    It "Should add 2 positive numbers" {
        $expected = 5 # Arrange
        $actual = Add-Numbers 2 3 # Act
        $actual | Should -Be $expected # Assert
    }
    It "Should add 2 negative numbers" {
        $expected = (-4)
        $actual = Add-Numbers (-2) (-2)
        $actual | Should -Be $expected
    }

    It "Should add one negative number to positive number" {
        $expected = 0
        $actual = Add-Numbers (-2) 2
        $actual | Should -Be $expected
    }

    It "Should concatenate strings if given strings" {
        $expected = "twothree"
        $actual = Add-Numbers two three
        $actual | Should -Be $expected
    }

}


  