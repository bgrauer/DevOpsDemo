﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "Add-Numbers" {
    It "should add positive numbers" {
        $expected = 5 # Arrange
        
        $actual = Add-Numbers 2 3 # Act
        
        $actual | Should -Be $expected # Assert
    }
}


  