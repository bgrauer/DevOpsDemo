﻿function Add-Numbers {

    [CmdletBinding()]
    Param
    (
        [int]$a,
        [int]$b
    )
    
    return $a + $b
}

function Subtract-Numbers {

    [CmdletBinding()]
    Param
    (
        [int]$a,
        [int]$b
    )
    
    return $a - $b
}

