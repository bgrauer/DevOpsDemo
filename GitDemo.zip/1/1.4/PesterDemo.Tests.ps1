﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "Subtract-Numbers" {
     It "Should subtract 2 positive numbers" {
        $expected = 5 # Arrange
        $actual = Subtract-Numbers 7 2 # Act
        $actual | Should -Be $expected # Assert
    }
}

Describe "Add-Numbers" {
    It "SHould add 2 positive numbers" {
        $expected = 5 # Arrange
        $actual = Add-Numbers 2 3 # Act
        $actual | Should -Be $expected # Assert
    }
    It "Should add 2 negative numbers" {
        $expected = (-4)
        $actual = Add-Numbers (-2) (-2)
        $actual | Should -Be $expected
    }

    It "Should add one negative number to positive number" {
        $expected = 0
        $actual = Add-Numbers (-2) 2
        $actual | Should -Be $expected
    }

}




  