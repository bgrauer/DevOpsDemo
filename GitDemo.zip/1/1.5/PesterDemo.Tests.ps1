﻿$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'
. "$here\$sut"

Describe "PesterDemo" {
    It "SHould Stop the bits service" {
        
        # Arrange
        try 
        {
            Start-Service bits 
        }
        catch
        {
            throw 'failed to start service - Bits'
        }
        
        PesterDemo # Act

        (Get-Service bits).Status | Should -Be "Stopped" # Assert
    }
 
}
