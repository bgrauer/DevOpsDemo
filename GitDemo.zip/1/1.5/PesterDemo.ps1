﻿function PesterDemo {

    Stop-Service bits
    
}
